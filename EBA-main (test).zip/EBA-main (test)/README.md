npm install jsonwebtoken bcryptjs cookie-parser

npm install mongoose


-to start the system-
npm start

